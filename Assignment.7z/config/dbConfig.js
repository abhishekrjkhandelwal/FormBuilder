module.exports = {
    dbUrl: "mongodb://localhost:27017/users"
}